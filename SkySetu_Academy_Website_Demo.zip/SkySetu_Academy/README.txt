SkySetu Academy — HTML Website Demo

How to preview:
1. Extract the ZIP file.
2. Open index.html in Chrome or another browser.

How to publish free:
- GitHub Pages or Netlify can host static HTML for free (account/setup required).
- Replace the placeholder PDF links, email, phone, and policy text with your real information.
- The YouTube button links to https://youtube.com/@skysetuacademy.
- This is a starter demo; it does not yet contain working PDF downloads or an MCQ database.
- AdSense approval is not guaranteed. Publish original, useful content and complete policy pages before applying.
